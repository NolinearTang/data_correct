#!/usr/bin/env python3
"""
Intent处理类
用于异步调用多个intent服务
"""

import asyncio
import aiohttp
from typing import List, Dict, Any
import time
from sanic import Sanic
from sanic.response import json

class Intent:
    """Intent类，表示一个意图服务"""
    
    def __init__(self, url: str):
        """
        初始化Intent
        
        Args:
            url: intent服务的访问地址
        """
        self.url = url
    
    async def intent_async(self, text: str, session: aiohttp.ClientSession) -> Dict[str, Any]:
        """
        异步调用intent服务
        
        Args:
            text: 要处理的文本
            session: 复用的aiohttp session
            
        Returns:
            包含处理结果的字典
        """
        start_time = time.time()
        
        try:
            async with session.post(
                self.url,
                json={"text": text},
                headers={"Content-Type": "application/json"},
                timeout=aiohttp.ClientTimeout(total=10)
            ) as response:
                if response.status == 200:
                    result = await response.json()
                    processing_time = time.time() - start_time
                    
                    print(f"Intent {self.url} 调用成功，耗时: {processing_time:.3f}s")
                    
                    return {
                        "status": "success",
                        "url": self.url,
                        "result": result,
                        "processing_time": processing_time,
                        "timestamp": time.time()
                    }
                else:
                    error_text = await response.text()
                    processing_time = time.time() - start_time
                    
                    print(f"Intent {self.url} 调用失败，状态码: {response.status}, 错误: {error_text}")
                    
                    return {
                        "status": "error",
                        "url": self.url,
                        "error": f"HTTP {response.status}: {error_text}",
                        "processing_time": processing_time,
                        "timestamp": time.time()
                    }
                    
        except asyncio.TimeoutError:
            processing_time = time.time() - start_time
            print(f"Intent {self.url} 调用超时")
            
            return {
                "status": "timeout",
                "url": self.url,
                "error": "请求超时",
                "processing_time": processing_time,
                "timestamp": time.time()
            }
            
        except Exception as e:
            processing_time = time.time() - start_time
            print(f"Intent {self.url} 调用异常: {e}")
            
            return {
                "status": "exception",
                "url": self.url,
                "error": str(e),
                "processing_time": processing_time,
                "timestamp": time.time()
            }

class IntentHandler:
    """Intent处理器，管理多个intent服务"""
    
    def __init__(self, base_url: str = "http://localhost:8000"):
        """
        初始化IntentHandler
        
        Args:
            base_url: intent服务的基础URL
        """
        self.base_url = base_url.rstrip('/')
        
        # 创建4个intent实例
        self.intent1 = Intent(f"{self.base_url}/intent1")
        self.intent2 = Intent(f"{self.base_url}/intent2")
        self.intent3 = Intent(f"{self.base_url}/intent3")
        self.intent4 = Intent(f"{self.base_url}/intent4")
        
        # 所有intent的列表
        self.intents = [self.intent1, self.intent2, self.intent3, self.intent4]
        
        print(f"IntentHandler 初始化完成，基础URL: {self.base_url}")
        print(f"包含 {len(self.intents)} 个intent服务")
    
    async def intent_all(self, text: str) -> List[Dict[str, Any]]:
        """
        异步调用所有intent服务
        
        Args:
            text: 要处理的文本
            
        Returns:
            所有intent服务的结果列表
        """
        print(f"开始调用所有intent服务，文本: '{text}'")
        start_time = time.time()
        
        # 创建复用的session
        async with aiohttp.ClientSession() as session:
            # 构建4个请求任务，传递session进行复用
            tasks = [
                intent.intent_async(text, session) for intent in self.intents
            ]
            
            # 提交所有任务并等待结果
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # 处理异常结果
            processed_results = []
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    print(f"Intent {i+1} 调用异常: {result}")
                    processed_results.append({
                        "status": "exception",
                        "url": self.intents[i].url,
                        "error": str(result),
                        "processing_time": 0,
                        "timestamp": time.time()
                    })
                else:
                    processed_results.append(result)
        
        total_time = time.time() - start_time
        
        # 统计结果
        successful_calls = sum(1 for r in processed_results if r.get("status") == "success")
        failed_calls = len(processed_results) - successful_calls
        
        print(f"所有intent服务调用完成:")
        print(f"  总调用数: {len(processed_results)}")
        print(f"  成功调用: {successful_calls}")
        print(f"  失败调用: {failed_calls}")
        print(f"  总耗时: {total_time:.3f}s")
        
        return processed_results
    
    async def intent_single(self, intent_name: str, text: str) -> Dict[str, Any]:
        """
        调用单个intent服务
        
        Args:
            intent_name: intent名称 (intent1, intent2, intent3, intent4)
            text: 要处理的文本
            
        Returns:
            intent服务的结果
        """
        intent_map = {
            "intent1": self.intent1,
            "intent2": self.intent2,
            "intent3": self.intent3,
            "intent4": self.intent4
        }
        
        if intent_name not in intent_map:
            return {
                "status": "error",
                "error": f"未知的intent名称: {intent_name}",
                "timestamp": time.time()
            }
        
        print(f"调用单个intent服务: {intent_name}, 文本: '{text}'")
        
        # 为单个调用创建session
        async with aiohttp.ClientSession() as session:
            return await intent_map[intent_name].intent_async(text, session)
    
    def get_intent_urls(self) -> List[str]:
        """获取所有intent的URL列表"""
        return [intent.url for intent in self.intents]

# 创建Sanic应用实例
app = Sanic("intent_handler_service")

# 创建全局的IntentHandler实例
intent_handler = IntentHandler()

@app.route("/intent_all", methods=["POST"])
async def intent_all_handler(request):
    """执行intent_all服务的主接口"""
    try:
        # 获取输入文本
        input_text = request.json.get("text", "")
        if not input_text:
            return json({"error": "请提供text参数"}, status=400)
        
        start_time = time.time()
        
        # 调用所有intent服务
        results = await intent_handler.intent_all(input_text)
        
        total_time = time.time() - start_time
        
        return json({
            "message": "intent_all服务执行完成",
            "input": input_text,
            "results": results,
            "total_processing_time": f"{total_time:.3f}s",
            "timestamp": time.time()
        })
        
    except Exception as e:
        print(f"intent_all服务执行错误: {e}")
        return json({"error": str(e)}, status=500)

@app.route("/")
async def root_handler(request):
    """根路径接口"""
    return json({
        "message": "IntentHandler服务",
        "description": "用于异步调用多个intent服务",
        "endpoints": {
            "intent_all": "/intent_all - 调用所有intent服务"
        },
        "usage": {
            "intent_all": {
                "method": "POST",
                "body": {"text": "你的文本内容"}
            }
        },
        "timestamp": time.time()
    })

# 使用示例
async def main():
    """主函数示例"""
    # 创建IntentHandler实例
    handler = IntentHandler()
    
    # 测试文本
    test_text = "你好世界"
    
    # 调用所有intent服务
    print("=== 调用所有intent服务 ===")
    all_results = await handler.intent_all(test_text)
    
    # 打印结果
    for i, result in enumerate(all_results):
        print(f"\nIntent {i+1} 结果:")
        print(f"  状态: {result.get('status')}")
        print(f"  URL: {result.get('url')}")
        if result.get('status') == 'success':
            print(f"  结果: {result.get('result')}")
            print(f"  处理时间: {result.get('processing_time'):.3f}s")
        else:
            print(f"  错误: {result.get('error')}")
    
    # 测试单个intent服务
    print("\n=== 调用单个intent服务 ===")
    single_result = await handler.intent_single("intent1", test_text)
    print(f"\n单个Intent1结果:")
    print(f"  状态: {single_result.get('status')}")
    if single_result.get('status') == 'success':
        print(f"  结果: {single_result.get('result')}")
        print(f"  处理时间: {single_result.get('processing_time'):.3f}s")
    else:
        print(f"  错误: {single_result.get('error')}")

if __name__ == "__main__":
    # 启动Sanic服务
    print("启动IntentHandler服务...")
    print("服务地址: http://localhost:8001/")
    print("主要接口: http://localhost:8001/intent_all")
    print("使用POST方法发送JSON数据，格式: {\"text\": \"你的文本\"}")
    
    app.run(host="0.0.0.0", port=8001, debug=True)

