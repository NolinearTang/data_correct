#!/usr/bin/env python3
"""
IntentHandler服务测试脚本
测试协程的并发性能
"""

import asyncio
import aiohttp
import time
import random
import string

def generate_random_text(length: int = 20) -> str:
    """生成随机文本"""
    chinese_chars = "你好世界测试协程异步并发性能优化"
    english_chars = string.ascii_letters
    digits = string.digits
    
    all_chars = chinese_chars + english_chars + digits
    return ''.join(random.choice(all_chars) for _ in range(length))

async def call_intent_all(text: str, task_id: int):
    """调用intent_all接口的协程任务"""
    start_time = time.time()
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                "http://localhost:8001/intent_all",
                json={"text": text},
                headers={"Content-Type": "application/json"},
                timeout=aiohttp.ClientTimeout(total=30)
            ) as response:
                if response.status == 200:
                    result = await response.json()
                    processing_time = time.time() - start_time
                    print(f"任务 {task_id} 成功，耗时: {processing_time:.3f}秒")
                    return {"status": "success", "task_id": task_id, "processing_time": processing_time}
                else:
                    processing_time = time.time() - start_time
                    print(f"任务 {task_id} 失败，状态码: {response.status}")
                    return {"status": "error", "task_id": task_id, "processing_time": processing_time}
                    
    except Exception as e:
        processing_time = time.time() - start_time
        print(f"任务 {task_id} 异常: {e}")
        return {"status": "error", "task_id": task_id, "processing_time": processing_time}

def intent_test():
    """同步任务方法：在for循环中使用asyncio.run()测试协程"""
    print("开始执行intent_test同步任务...")
    
    # 生成100个随机文本
    texts = []
    for i in range(100):
        text = generate_random_text(random.randint(10, 30))
        texts.append(f"测试文本_{i+1}: {text}")
    
    print(f"生成了 {len(texts)} 个测试文本")
    
    # 在for循环中使用asyncio.run()测试协程
    start_time = time.time()
    successful_calls = 0
    failed_calls = 0
    
    for i, text in enumerate(texts):
        task_id = i + 1
        print(f"开始执行任务 {task_id}")
        
        try:
            # 在for循环中直接使用asyncio.run()运行协程
            result = asyncio.run(call_intent_all(text, task_id))
            
            if result.get("status") == "success":
                successful_calls += 1
                print(f"任务 {task_id} 执行成功")
            else:
                failed_calls += 1
                print(f"任务 {task_id} 执行失败")
                
        except Exception as e:
            failed_calls += 1
            print(f"任务 {task_id} 执行异常: {e}")
    
    end_time = time.time()
    total_time = end_time - start_time
    
    # 输出统计结果
    print("=" * 50)
    print("协程测试完成！统计结果:")
    print(f"  总任务数: {len(texts)}")
    print(f"  成功执行: {successful_calls}")
    print(f"  失败执行: {failed_calls}")
    print(f"  总耗时: {total_time:.3f}秒")
    print(f"  平均每个任务耗时: {total_time/len(texts):.3f}秒")
    print("=" * 50)


if __name__ == "__main__":
    intent_test()
