# 协程测试项目

这个项目用于测试协程功能，使用Sanic框架启动4个不同的intent服务，运行在同一端口的不同路径。

## 服务说明

### Intent服务（端口8000）
所有服务运行在端口 **8000** 上，路径分别为：
- **intent1**: `/intent1` - 第一个意图服务
- **intent2**: `/intent2` - 第二个意图服务
- **intent3**: `/intent3` - 第三个意图服务
- **intent4**: `/intent4` - 第四个意图服务

### IntentHandler服务（端口8001）
- **端口**: 8001
- **主要功能**: 执行intent_all服务，异步调用所有intent服务
- **接口**: `/intent_all` - 主要接口，调用所有intent服务

## 安装依赖

```bash
pip install -r requirements.txt
```

## 运行服务

### 1. 启动Intent服务
```bash
python main.py
```

### 2. 启动IntentHandler服务
```bash
python intent_handler.py
```

## API接口

### Intent服务接口
所有服务都使用POST方法，接收JSON格式的文本参数：

- **URL**: `http://localhost:8000/intent1`
- **URL**: `http://localhost:8000/intent2`
- **URL**: `http://localhost:8000/intent3`
- **URL**: `http://localhost:8000/intent4`
- **方法**: POST
- **请求体**: `{"text": "你的文本内容"}`
- **响应**: JSON格式的处理结果

### IntentHandler服务接口

#### 主要接口 - intent_all
- **URL**: `http://localhost:8001/intent_all`
- **方法**: POST
- **请求体**: `{"text": "你的文本内容"}`
- **功能**: 异步调用所有4个intent服务，返回所有结果

#### 其他接口
- **URL**: `http://localhost:8001/` - 服务信息

## 测试示例

### 测试Intent服务
```bash
# 测试intent1服务
curl -X POST http://localhost:8000/intent1 \
  -H "Content-Type: application/json" \
  -d '{"text": "你好世界"}'

# 测试intent2服务
curl -X POST http://localhost:8000/intent2 \
  -H "Content-Type: application/json" \
  -d '{"text": "测试文本"}'
```

### 测试IntentHandler服务
```bash
# 调用所有intent服务
curl -X POST http://localhost:8001/intent_all \
  -H "Content-Type: application/json" \
  -d '{"text": "你好世界"}'

# 查看服务信息
curl http://localhost:8001/
```

## IntentHandler类

项目还包含一个 `IntentHandler` 类，用于异步调用多个intent服务：

### 使用方法

```python
from intent_handler import IntentHandler

# 创建IntentHandler实例
handler = IntentHandler()

# 异步调用所有intent服务
async def test_all_intents():
    results = await handler.intent_all("你好世界")
    for result in results:
        print(f"状态: {result['status']}")
        print(f"结果: {result.get('result', 'N/A')}")

# 运行测试
import asyncio
asyncio.run(test_all_intents())
```

## 项目结构

- `main.py` - Sanic服务主程序（端口8000）
- `intent_handler.py` - IntentHandler类和Sanic服务（端口8001）
- `test_script.py` - 性能测试脚本
- `requirements.txt` - 项目依赖
- `README.md` - 项目说明

## 使用流程

1. **启动Intent服务**: `python main.py` (端口8000)
2. **启动IntentHandler服务**: `python intent_handler.py` (端口8001)
3. **调用intent_all接口**: 向 `http://localhost:8001/intent_all` 发送POST请求
4. **获取结果**: IntentHandler会异步调用所有4个intent服务并返回结果

## 性能测试

使用测试脚本进行性能测试：

```bash
# 运行性能测试
python test_script.py
```

### 测试脚本功能

- **生成100个随机文本**: 包含中文、英文、数字的混合文本
- **创建100个协程任务**: 每个任务调用一次intent_all接口
- **并发执行**: 使用asyncio.gather并发执行所有任务
- **性能统计**: 统计总耗时、成功率、平均处理时间等指标

### 测试结果示例

```
==================================================
测试完成！统计结果:
  总任务数: 100
  成功执行: 100
  失败执行: 0
  总耗时: 15.234秒
  平均每个任务耗时: 0.152秒
  成功任务平均处理时间: 0.145秒
==================================================
```
