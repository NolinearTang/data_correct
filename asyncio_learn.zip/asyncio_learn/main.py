#!/usr/bin/env python3
"""
协程测试主程序
使用Sanic框架启动4个不同的intent服务，运行在同一端口不同路径
"""

import asyncio
from sanic import Sanic
from sanic.response import json
import time
import random

# 创建单个Sanic应用实例
app = Sanic("intent_services")

# 配置端口
PORT = 8000

# Intent1 服务路由
@app.route("/intent1", methods=["POST"])
async def intent1_handler(request):
    """Intent1 服务处理函数"""
    try:
        # 获取输入文本
        input_text = request.json.get("text", "")
        if not input_text:
            return json({"error": "请提供text参数"}, status=400)
        
        start_time = time.time()
        
        # 同步sleep 0.5秒
        time.sleep(0.5)
        
        # 直接返回结果
        result = f"Intent1 处理结果: {input_text}"
        
        processing_time = time.time() - start_time
        return json({
            "service": "intent1",
            "input": input_text,
            "result": result,
            "processing_time": f"{processing_time:.3f}s",
            "timestamp": time.time()
        })
    except Exception as e:
        print(f"Intent1 处理错误: {e}")
        return json({"error": str(e)}, status=500)

# Intent2 服务路由
@app.route("/intent2", methods=["POST"])
async def intent2_handler(request):
    """Intent2 服务处理函数"""
    try:
        # 获取输入文本
        input_text = request.json.get("text", "")
        if not input_text:
            return json({"error": "请提供text参数"}, status=400)
        
        start_time = time.time()
        
        # 同步sleep 0.5秒
        time.sleep(0.5)
        
        # 直接返回结果
        result = f"Intent2 处理结果: {input_text}"
        
        processing_time = time.time() - start_time
        return json({
            "service": "intent2",
            "input": input_text,
            "result": result,
            "processing_time": f"{processing_time:.3f}s",
            "timestamp": time.time()
        })
    except Exception as e:
        print(f"Intent2 处理错误: {e}")
        return json({"error": str(e)}, status=500)

# Intent3 服务路由
@app.route("/intent3", methods=["POST"])
async def intent3_handler(request):
    """Intent3 服务处理函数"""
    try:
        # 获取输入文本
        input_text = request.json.get("text", "")
        if not input_text:
            return json({"error": "请提供text参数"}, status=400)
        
        start_time = time.time()
        
        # 同步sleep 0.5秒
        time.sleep(0.5)
        
        # 直接返回结果
        result = f"Intent3 处理结果: {input_text}"
        
        processing_time = time.time() - start_time
        return json({
            "service": "intent3",
            "input": input_text,
            "result": result,
            "processing_time": f"{processing_time:.3f}s",
            "timestamp": time.time()
        })
    except Exception as e:
        print(f"Intent3 处理错误: {e}")
        return json({"error": str(e)}, status=500)

# Intent4 服务路由
@app.route("/intent4", methods=["POST"])
async def intent4_handler(request):
    """Intent4 服务处理函数"""
    try:
        # 获取输入文本
        input_text = request.json.get("text", "")
        if not input_text:
            return json({"error": "请提供text参数"}, status=400)
        
        start_time = time.time()
        
        # 同步sleep 0.5秒
        time.sleep(0.5)
        
        # 直接返回结果
        result = f"Intent4 处理结果: {input_text}"
        
        processing_time = time.time() - start_time
        return json({
            "service": "intent4",
            "input": input_text,
            "result": result,
            "processing_time": f"{processing_time:.3f}s",
            "timestamp": time.time()
        })
    except Exception as e:
        print(f"Intent4 处理错误: {e}")
        return json({"error": str(e)}, status=500)

# 根路径路由
@app.route("/")
async def root_handler(request):
    """根路径处理函数"""
    return json({
        "message": "协程测试服务",
        "services": [
            "intent1",
            "intent2", 
            "intent3",
            "intent4"
        ],
        "endpoints": {
            "intent1": "/intent1",
            "intent2": "/intent2",
            "intent3": "/intent3", 
            "intent4": "/intent4"
        }
    })

if __name__ == "__main__":
    print("开始启动协程测试服务...")
    print("服务路径:")
    print("  intent1: http://localhost:8000/intent1")
    print("  intent2: http://localhost:8000/intent2")
    print("  intent3: http://localhost:8000/intent3")
    print("  intent4: http://localhost:8000/intent4")
    print("使用POST方法发送JSON数据，格式: {\"text\": \"你的文本\"}")
    
    # 直接启动服务
    app.run(host="0.0.0.0", port=PORT, debug=True)
